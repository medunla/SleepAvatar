//
//  AboutSleepDetailViewController.h
//  SleepAvatar
//
//  Created by panupatnew on 3/22/2558 BE.
//  Copyright (c) 2558 medunla. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutSleepDetailViewController : UIViewController

@end
