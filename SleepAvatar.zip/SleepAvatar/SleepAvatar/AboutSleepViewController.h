//
//  AboutSleepViewController.h
//  SleepAvatar
//
//  Created by panupatnew on 2/7/2558 BE.
//  Copyright (c) 2558 medunla. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECSlidingViewController.h"

@interface AboutSleepViewController : UIViewController

- (IBAction)menuButtonTapped:(id)sender;

@end
